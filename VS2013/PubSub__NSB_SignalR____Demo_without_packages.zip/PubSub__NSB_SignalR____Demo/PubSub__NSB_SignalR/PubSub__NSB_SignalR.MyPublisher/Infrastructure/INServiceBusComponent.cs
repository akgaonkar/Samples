﻿namespace NServiceBus
{
    public interface INServiceBusComponent
    {
    }
}