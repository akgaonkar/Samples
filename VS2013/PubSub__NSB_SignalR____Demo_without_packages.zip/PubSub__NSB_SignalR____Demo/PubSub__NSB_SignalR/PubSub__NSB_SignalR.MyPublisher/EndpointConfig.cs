﻿using System;
using NServiceBus;
 
namespace PubSub__NSB_SignalR.MyPublisher
{
	public partial class EndpointConfig : IConfigureThisEndpoint, AsA_Publisher    
	{
    }
}
