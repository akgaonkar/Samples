﻿using System;
using NServiceBus;


namespace PubSub__NSB_SignalR.Notifications
{
    public partial class EventMessageSender
    {
		
            // call Bus.Publish<PubSub__NSB_SignalR.Contract.Notifications.EventMessage>(m => { /* set properties on m in here */ });

    }
}
